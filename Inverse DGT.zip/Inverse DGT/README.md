# Racing_Game
## Inverse DGT

This project was started as an assigment for the Physics II, subject at CITM, UPC Terrassa. Created by one student in the second year of the Videogames Design and Development career. 
The idea was to create this mini game where you drive a car and prove some physics.
The game consists in a race that you have to drive over the mininum speed that changes every 10 seconds. If you are below the mininum speed you lose.


### Controls
- "UP" for go forward.

- "LEFT" for left direction.

- "RIGHT" for right direction.

- "DOWN" for go backward.

Special debug keys:

- F1 to make the time to 100.
- F2 to change the camera view.
- F3 to reset.

### Autors
- Josep Sànchez Arbona: all.


### Github
- https://github.com/daskza19/Racing_Game

### Disclosure

I do not own all of the tilesets, music or sfx presented in this game. Authors credited below
-Music: 
	Castelvania II - Bloody Tears by Kenichi Matsubara, Masahiro Ikariko, Kazuhiko Uehara, and T-San
	Lose Sound - https://www.youtube.com/watch?v=jAIlKqL3nHo

### License

//MIT License

Copyright (c) [2019] [JOSEP SÀNCHEZ ARBONA]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.//